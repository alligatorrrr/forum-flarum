import app from 'flarum/forum/app';
import { extend } from 'flarum/common/extend';
import Application from 'flarum/common/Application';

import MobileTab from './components/MobileTab';
import SessionDropdown from 'flarum/forum/components/SessionDropdown';
import LinkButton from 'flarum/common/components/LinkButton';
import username from "../../../../../flarum/core/js/dist-typings/common/helpers/username";

app.initializers.add('annonny/bookmark-discussions', () => {
  extend(SessionDropdown.prototype, 'items', function (items) {
    if (app.session.user) {
      items.add('bookmark-discussions', LinkButton.component({
        icon: 'fas fa-bookmark',
        href: '/bookmarked-discussions',
      }, '收藏'));
    }
  });
});
app.initializers.add('annonny/bookmark-discussions-list', () => {
  extend(SessionDropdown.prototype, 'items', function (items) {
    if (app.session.user) {
      items.add('bookmark-discussions-list', LinkButton.component({
        icon: 'fas fa-list-ol',
        href: app.route('user', { username: app.session.user.slug()})+"/discussion-lists",
      }, '文库/文集'));
    }
  });
});

app.initializers.add('acpl/mobile-tab', () => {
  extend(Application.prototype, 'mount', () => {
    const mTab = document.createElement('div');
    m.mount(document.body.appendChild(mTab), MobileTab);
  });
});

export * from './components';
