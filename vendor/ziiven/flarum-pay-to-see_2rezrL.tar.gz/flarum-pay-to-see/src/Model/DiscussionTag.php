<?php

namespace Ziven\pay2see\Model;

use Flarum\Database\AbstractModel;
use Flarum\Database\ScopeVisibilityTrait;
use Flarum\User\User;
use Flarum\Discussion\Discussion;

class DiscussionTag extends AbstractModel{
    use ScopeVisibilityTrait;
    protected $table = 'discussion_tag';
}
