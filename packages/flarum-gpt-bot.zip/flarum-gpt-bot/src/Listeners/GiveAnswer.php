<?php

namespace Annonny\GptBot\Listeners;

use Annonny\GptBot\Job\SendBotReplyJob;
use Illuminate\Contracts\Bus\Dispatcher;
use Flarum\Post\Event\Posted;
use Flarum\Post\CommentPost;
use Illuminate\Contracts\Queue\Queue;

class GiveAnswer
{
    protected $events;
    private $queue;

    public function __construct(Dispatcher $events, Queue $queue)
    {
        $this->events = $events;
        $this->queue = $queue;
    }

    public function postWasPosted(Posted $event)
    {
        // 获取当前发布的帖子
        $post = $event->post;


        // 如果帖子的内容中包含机器人的 @ 提及，则自动回复
        if (strpos($post->content, '@bot') !== false || strpos($post->content, '@"MORA[bot]"') !== false) {
            // 获取原帖作者
            $user = $post->user;
            // 获取提醒文本
            $mention = "@\"" . $user->display_name . "\"#p" . $post->id;
            // 处理用户文本
            $question_content = str_replace("@bot", "", $post->content);
            $question_content = str_replace('@"MORA[bot]"', '', $question_content);
            $pattern = '/#p?\d+/';
            $replacement = '';
            $question_content = preg_replace($pattern, $replacement, $question_content);
            $pattern = '/:zhongli_discord_\d+:/';
            $question_content = preg_replace($pattern, $replacement, $question_content);
            $question_content = trim($question_content);
            if ($question_content == "") {
                $result = "您的消息似乎是一个空白字符。需要MORA为您提供什么帮助吗？" . array(':zhongli_discord_17:', ':zhongli_discord_27:')[rand(0, 1)];
                $content = $mention . " " . $result;
                $bot_reply = CommentPost::reply($post->discussion_id, $content, 50, null);
                $bot_reply->save();
                $bot_reply->mentionsPosts()->sync($post);
                $discussion = $post->discussion;
                $discussion->refreshLastPost();
                $discussion->refreshCommentCount();
                $discussion->refreshParticipantCount();
                $discussion->save();
            } else {
                $this->queue->push(new SendBotReplyJob($post, $question_content, $mention));
            }
        }
    }

}
