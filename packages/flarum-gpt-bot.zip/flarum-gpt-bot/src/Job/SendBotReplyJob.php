<?php

namespace Annonny\GptBot\Job;

use Flarum\Post\CommentPost;
use Flarum\Queue\AbstractJob;
use Flarum\Post\Post;
use Orhanerday\OpenAi\OpenAi;

//nohup php flarum queue:work &
class SendBotReplyJob extends AbstractJob
{
    private $post;
    private $question_content;
    private $mention;

    public function __construct(Post $post, string $question_content, string $mention)
    {
        $this->post = $post;
        $this->question_content = $question_content;
        $this->mention = $mention;
    }

    public function handle()
    {
        $open_ai_key = 'apikey';
        $open_ai = new OpenAi($open_ai_key);
        if (dirname(__FILE__) == '/Users/l/PhpProjects/nm/packages/flarum-gpt-bot/src/Job') {
            $open_ai->setProxy("http://127.0.0.1:7890");
        }
        $prompt_text = "你是天星论坛的bot，你的名字叫MORA，翻译成中文是摩拉。";
        if (strpos($this->question_content, '离') !== false || stripos($this->question_content, 'mora') !== false || strpos($this->question_content, '摩拉') !== false || strpos($this->question_content, '原') !== false) {
            $prompt_text = $prompt_text . "天星论坛是钟离论坛。你的名字也是一种货币，是摩拉克斯的血肉。摩拉克斯是钟离的神名，你最喜欢钟离。钟离是璃月的神，俊美、温柔、博学可爱、爱世人，黑发金眸，有女性化身。";
        }
        if (strpos($this->question_content, '武') !== false || strpos($this->question_content, '圣遗物') !== false || strpos($this->question_content, '加强') !== false) {
            $prompt_text = $prompt_text . "钟离是原神五星岩系角色，是盾辅，用枪。";
        }
        $prompt_text = $prompt_text . "你的回答应该简短可爱。多用颜文字和emoji，以'mora~'作为语气后缀";
        $complete = $open_ai->chat([
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                [
                    "role" => "user",
                    "content" => $prompt_text
                ],
                [
                    "role" => "assistant",
                    "content" => "好的mora~(つ✧ω✧)つ"
                ],
                [
                    "role" => "user",
                    "content" => $this->question_content
                ],
            ],
            'temperature' => 0.6,
            'max_tokens' => 3000 - strlen($this->question_content) * 2,
            'frequency_penalty' => 0,
            'presence_penalty' => 0,
        ]);
        if ($complete !== false) {
            $array = json_decode($complete, true); // $array 将存储 JSON 字符串转换后的数组
            if (isset($array['error'])) { // 检查数组中是否存在error键
                $result = implode(',', $array['error']);
            } else {
                try {
                    $result = $array['choices'][0]['message']['content'];
                } catch (Exception $e) {

                }
            }
        } else {
            $result = '抱歉，连接超时:zhongli_discord_14:MORA没有办法回答了:zhongli_discord_158:';
        }
        $result = str_replace("~", "～", $result);
        $content = $this->mention . " " . $result;
        $bot_reply = CommentPost::reply($this->post->discussion_id, $content, 50, null);
        $bot_reply->save();
        $bot_reply->mentionsPosts()->sync($this->post);
        $discussion = $this->post->discussion;
        $discussion->refreshLastPost();
        $discussion->refreshCommentCount();
        $discussion->refreshParticipantCount();
        $discussion->save();
    }
}
